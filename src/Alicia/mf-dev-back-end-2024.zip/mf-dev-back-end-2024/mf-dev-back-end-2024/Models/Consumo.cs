﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace mf_dev_back_end_2024.Models
{
    [Table("Consumos")]
    public class Consumo
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Obrigatorio informar a descricao")]
        [Display(Name = "Descricao")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "Obrigatorio informar a data")]
        public DateTime Data { get; set; }

        [Required(ErrorMessage = "Obrigatorio informar o valor")]
        public decimal Valor { get; set; }

        [Required(ErrorMessage = "Obrigatorio informar a quilometragem")]
        public int Km { get; set; }

        [Display(Name = "Tipo de combustivel")]
        public TipoCombustivel Tipo { get; set; }

        [Display(Name = "Veiculo")]
        [ForeignKey("VeiculoId")]
        [Required(ErrorMessage = "Obrigatorio informar o veiculo")]
        public int VeiculoId { get; set; }

        public Veiculo Veiculo { get; set; }
    }

    public enum TipoCombustivel
    {
        Gasolina,
        Etanol
    }
}
